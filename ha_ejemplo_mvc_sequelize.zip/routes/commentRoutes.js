const express = require("express");
const router = express.Router();

// Rutas relacionadas a los comentarios:
// ...

module.exports = router;
