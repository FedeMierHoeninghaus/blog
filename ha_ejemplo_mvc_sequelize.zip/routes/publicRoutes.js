const express = require("express");
const router = express.Router();

// Rutas relacionadas a la parte pública del sitio web:
// ...

module.exports = router;
